import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  Myform: FormGroup;
  ngOnInit(): void {
    this.Myform = new FormGroup({

      "firstname":new FormControl("",[Validators.required]),
      "lastname":new FormControl("",[Validators.required]),
     "email" : new FormControl("",[Validators.required]),
     "city"  :new FormControl("",[Validators.required]),
     "state" : new FormControl("",[Validators.required])
  
     });

     }
  
     save(){
      localStorage.setItem("formdata",JSON.stringify(this.Myform.value));
      var formValue = JSON.parse(localStorage.getItem('formdata'));
      console.log(this.Myform.value)
      this.Myform.reset();
    }
  }
 




